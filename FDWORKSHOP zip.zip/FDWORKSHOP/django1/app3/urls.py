from django.urls import path
from app3.views import home
urlpatterns = [path('', home),]